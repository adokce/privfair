INSERT INTO data (username, password, role) VALUES
  ('alice', 'alice', 'owner'),
  ('bob', 'bob', 'evaluator'),
  ('test', 'test', 'evaluator');