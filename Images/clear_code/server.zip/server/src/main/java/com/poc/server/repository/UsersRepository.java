package com.poc.server.repository;

import com.poc.server.entity.Data;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsersRepository extends JpaRepository<Data, Long> {
    Optional<Data> findByUsername(String name);
}
