package com.poc.server.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.poc.server.docker.DockerService;
import com.poc.server.entity.Data;
import com.poc.server.model.Message;
import com.poc.server.model.Request;
import com.poc.server.model.Response;
import com.poc.server.model.User;
import com.poc.server.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.*;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
public class WebController {

    @Autowired
    DockerService dockerService;

    @Autowired
    SimpMessagingTemplate template;

    @Autowired
    UsersRepository usersRepository;

    @Value("${upload.folder}")
    private String folderPath;

    @GetMapping("/health")
    public ResponseEntity<String> health(){
        return new ResponseEntity<>("Server OK", HttpStatus.OK);
    }

    @GetMapping("/sendCmd/{user}")
    public ResponseEntity<String> getList(@PathVariable String user){
        Optional<Data> data = usersRepository.findByUsername(user);
        dockerService.sendCmd(data.get());
        return new ResponseEntity<>("result", HttpStatus.OK);
    }

    @PostMapping("/login")
    public ResponseEntity<String> getLogin(@RequestBody User user) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        Optional<Data> data = usersRepository.findByUsername(user.getName());
        if(data.isPresent()){

            Data userData = data.get();
            if(userData.getPassword().equals(user.getPassword())){
                String id = dockerService.initiateProcess(userData);
                userData.setActive(true);
                userData.setContainer(id);
                usersRepository.save(userData);
                return new ResponseEntity<>(id, HttpStatus.OK);
            }else{
                return new ResponseEntity<>("Not Authorized", HttpStatus.UNAUTHORIZED);
            }
        }else{
            return new ResponseEntity<>("User Not Found", HttpStatus.NOT_FOUND);
        }
    }


    @PostMapping("/user/create")
    public ResponseEntity<Data> createUser(@RequestBody User user) throws IOException {
        Data data = Data.builder()
                .username(user.getName())
                .password(user.getPassword())
                .role(user.getRole()).build();

        Data savedData = usersRepository.save(data);
        return new ResponseEntity<>(savedData, HttpStatus.OK);
    }

    @GetMapping("/start/{user}")
    public ResponseEntity<String> startContainer(@PathVariable String user){
        Optional<Data> userData = usersRepository.findByUsername(user);
        if(userData.isPresent()){
            dockerService.startContainer(userData.get().getContainer());
            return new ResponseEntity<String>("Started", HttpStatus.ACCEPTED);
        }else{
            return new ResponseEntity<String>("User Not Found", HttpStatus.NOT_FOUND);
        }

    }



    @DeleteMapping("/logout/{user}")
    public ResponseEntity<String> logout(@PathVariable String user){
        Optional<Data> data = usersRepository.findByUsername(user);
        if(data.isPresent()){
            dockerService.terminateInstance(data.get().getContainer());
            return new ResponseEntity<String>("Deleted", HttpStatus.ACCEPTED);
        }else{
            return new ResponseEntity<>("User Not Found", HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping(value = "/copy/{user}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> copyTar(@PathVariable String user, @RequestPart(value = "file") MultipartFile file) throws IOException {
        new File(folderPath+user).mkdir();
        file.transferTo(new File(folderPath + user + "/" + file.getOriginalFilename()));
        return new ResponseEntity<String>("Copied", HttpStatus.ACCEPTED);
    }


    @PostMapping(value = "/files/{user}")
    public ResponseEntity<String> uploadFile(@RequestParam(value = "file") MultipartFile file, @PathVariable String user) throws IOException {

        Optional<Data> userData = usersRepository.findByUsername(user);
        if(userData.isPresent()){
            new File(folderPath+user).mkdir();
            file.transferTo(new File(folderPath + user + "/" + file.getOriginalFilename()));
            System.out.println("Sendding File: " + folderPath + user + "/" + file.getOriginalFilename());
            dockerService.copyTar(userData.get().getContainer(), new File(folderPath + user + "/" + file.getOriginalFilename()));
            return new ResponseEntity<>(file.getOriginalFilename(), HttpStatus.ACCEPTED);
        }else{
            return new ResponseEntity<>("User Not found", HttpStatus.NOT_FOUND);
        }

    }

    @PostMapping("/message/{user}")
    public ResponseEntity<Void> sendMessage(@RequestBody Message message, @PathVariable String user) throws IOException {
        template.convertAndSend("/topic/view"+user, message);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}
