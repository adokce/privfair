package com.poc.server.docker;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.async.ResultCallback;
import com.github.dockerjava.api.command.*;
import com.github.dockerjava.api.model.Frame;
import com.github.dockerjava.api.model.HostConfig;
import com.github.dockerjava.api.model.ResponseItem;
import com.github.dockerjava.core.DockerClientBuilder;
import com.github.dockerjava.core.command.ExecStartResultCallback;
import com.github.dockerjava.core.command.LogContainerResultCallback;
import com.poc.server.entity.Data;
import com.poc.server.model.Message;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.*;
import java.util.Arrays;

@Component
public class DockerService {

    @Autowired
    SimpMessagingTemplate template;

    DockerClient dockerClient;

    @PostConstruct
    public void init(){
        dockerClient = DockerClientBuilder.getInstance().build();
    }

    public String initiateProcess(Data user) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();

        //Creating the container
        template.convertAndSend("/topic/view/" + user, "Creating the container");
        String containerId = createContainer(user);
        template.convertAndSend("/topic/view/" + user, "Created the container with id:- " + containerId);

        //Starting the container
        template.convertAndSend("/topic/view/" + user, "Starting the container" );
        startContainer(containerId);
        template.convertAndSend("/topic/view/" + user, "Started the container ");

        return containerId;
    }

    public void terminateInstance(String id){
        if(!status(id).equalsIgnoreCase("existed")){
            stopContainer(id);
        }
        deleteContainer(id);
    }

    private String createContainer(Data user){
        System.out.println("Creating container");
        CreateContainerResponse container
                = dockerClient.createContainerCmd("test")
                .withAttachStdout(true)
                .withAttachStderr(true)
                .withTty(true)
                .withHostConfig(HostConfig.newHostConfig().withNetworkMode("privfair"))
                .withNetworkDisabled(false)
                .withCmd("/bin/bash")
                .withName(user.getUsername() + "-" + user.getRole())
                .withHostName(user.getUsername()).exec();
        System.out.println("Status after creation: " + container.getId());
        return container.getId();
    }

    public void startContainer(String id){
        System.out.println("Starting container");
        dockerClient.startContainerCmd(id).exec();
        System.out.println("Status after start: " + status(id));
    }

    public String copyTar(String id, File file){
        dockerClient.copyArchiveToContainerCmd(id).withHostResource(file.getAbsolutePath()).withRemotePath("/tmp").exec();
        return "success";
    }

    public void sendCmd(Data user){
        System.out.println("Sending Command: " + user);
        ExecCreateCmdResponse response = dockerClient.execCreateCmd(user.getContainer()).withAttachStdout(true).withAttachStderr(true).withAttachStdin(true).withCmd("python3", "main.py").exec();
        dockerClient.execStartCmd(response.getId())
                .exec(new ResultCallback.Adapter<>(){
                    @Override
                    public void onNext(Frame object) {
                        System.out.println(new String(object.getPayload()).trim());
                        template.convertAndSend("/topic/view/" + user.getUsername(), Message.builder().type("log").message(new String(object.getPayload()).trim()).build());
                    }
                });
    }

    private String status(String id){
        InspectContainerResponse inspectContainerResponse
                = dockerClient.inspectContainerCmd(id).exec();
        return inspectContainerResponse.getState().getStatus();
    }

    private void printLogs(String id) {
        LogContainerCmd logContainerCmd = dockerClient.logContainerCmd(id).withStdOut(true).withStdErr(true).withFollowStream(true);
        ResultCallback<Frame> callback = new ResultCallback<Frame>() {
            @Override
            public void onStart(Closeable closeable) {
                System.out.println("logs started");
            }

            @Override
            public void onNext(Frame object) {
                System.out.println("logs:- " + object.toString());
            }

            @Override
            public void onError(Throwable throwable) {
                System.out.println("logs error");
            }

            @Override
            public void onComplete() {
                System.out.println("logs complete");
            }

            @Override
            public void close() throws IOException {
                System.out.println("logs close");
            }
        };
        logContainerCmd.exec(callback);
    }

    private String stopContainer(String id){
        System.out.println("Stopping container");
        dockerClient.stopContainerCmd(id).exec();
        String s1 = status(id);
        System.out.println("Status after stop: " + s1);
        return s1;

    }

    private void deleteContainer(String id){
        System.out.println("Removing container");
        dockerClient.removeContainerCmd(id).exec();
    }


}
