package com.poc.server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class WebSocketController {

    @Autowired
    SimpMessagingTemplate template;

    @MessageMapping("/spdz")
    @SendTo("/topic/spdz")
    public String getMessage(@Payload String message){
        //Alice send("/app/spdz", message)
        //Alice subscribe("/topic/alice")

        ////Spdz  send("/app/alice", message)
        //Spdz  subscribe("/topic/spdz")
        System.out.println("websock: " + message);
      return message;
    }

    @MessageMapping("/alice")
    @SendTo("/topic/alice")
    public String getMessageAlice(@Payload String message){
        System.out.println("websock: " + message);
        return message;
    }
}
