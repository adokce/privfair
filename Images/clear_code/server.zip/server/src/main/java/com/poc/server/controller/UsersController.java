package com.poc.server.controller;

import com.poc.server.entity.Data;
import com.poc.server.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UsersController {

    @Autowired
    UsersRepository usersRepository;

    @GetMapping("/users")
    public ResponseEntity<List<Data>> getUsers(){
        List<Data> users = usersRepository.findAll();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }
}
