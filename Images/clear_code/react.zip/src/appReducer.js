import { updateObject } from "utils";

const reducer = (state, action) => {
  switch (action.type) {
    case "LOGIN":
      return updateObject(state, {
        login: updateObject(state.login, {
          status: true,
          role: action.role,
          userDetails: {
            name: action.name
          }
        }),
      });
    case "LOGOUT":
      return updateObject(state, {
        login: updateObject(state.login, {
          status: false,
          role: null,
          // userDetails: null
        }),
      });
    case "UPDATE_STEPPER_SUBMIT_HANDLER":
      return updateObject(state, {
        handlers: updateObject(state.handlers, {
          stepperSubmitHandler: action.cb,
        }),
      });
    case 'UPDATE_SOCKET_MSG_HANDLER': 
      return updateObject(state, {
        handlers: updateObject(state.handlers, {
          sockMsgHandler: action.cb
        })
      })
    case "RESULT_PROGRESS":

      return updateObject(state, {
        results: [...state.results, action.msg]
      })
    default:
      return state;
  }
};

export default reducer;
