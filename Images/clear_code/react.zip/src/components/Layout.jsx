import { useState, memo, useContext } from "react";
import {
  CssBaseline,
  AppBar,
  Typography,
  IconButton,
  Toolbar,
  Menu,
  MenuItem,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { AccountCircle as AccountCircleIcon } from "@material-ui/icons";
import { useHistory } from "react-router-dom";

import { AppContext } from "App";
import axios from "axios";
import { API_URL } from "consts";

const useStyles = makeStyles((theme) => ({
  hide: {
    display: "none",
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  root: {
    flexGrow: 1,
  },
  title: {
    flexGrow: 1,
  },
}));

function Layout({ auth, logout, children }) {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const { appState, appMethods } = useContext(AppContext);
  const history = useHistory();

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const logoutHandler = () => {
    axios.delete(API_URL + "/logout/" + appState.login.userDetails.name)
    appMethods.logoutHandler();
    handleClose();
    history.push("/");
  };

  return (
    <div className={classes.root}>
      <CssBaseline />

      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" className={classes.title}>
            PrivFair
          </Typography>
          {appState.login.status && (
            <div>
              <IconButton
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                color="inherit"
              >
                <AccountCircleIcon />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={open}
                onClose={handleClose}
              >
                <MenuItem onClick={handleClose}>
                  {appState.login.userDetails.name}
                </MenuItem>
                <MenuItem onClick={logoutHandler}>Logout</MenuItem>
              </Menu>
            </div>
          )}
        </Toolbar>
      </AppBar>

      <main className={classes.content}>{children}</main>
    </div>
  );
}

export default memo(Layout);
