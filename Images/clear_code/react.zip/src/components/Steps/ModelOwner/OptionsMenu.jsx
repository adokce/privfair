import React, { useEffect, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import { Typography } from "@material-ui/core";
import { AppContext } from "App";
import axios from 'axios'
import { API_URL } from "consts";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100%",
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
  },
  button: {
    height: "fit-content",
    alignSelf: "center",
    margin: "0 24px",
  },
  inputButton: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    textAlign: "center",
  },
}));

export default function OptionsMenu(props) {
  const classes = useStyles();
  const { handleNext, setModelFile, modelFile } = props;
  const { appMethods, appState } = useContext(AppContext);


  const onSelectImages = (e) => {
    let uploadedFiles = e.target.files[0];

    var formData = new FormData()
    formData.append('file', uploadedFiles)

    axios.post(API_URL + '/files/'+appState.login.userDetails.name, formData).then(res => {
      axios.get(API_URL + '/sendCmd/'+appState.login.userDetails.name)
    })
    // setModelFile(uploadedFiles);
    handleNext()
  };

  const handleModel = (e) => {};

  useEffect(() => {
    setModelFile(null);
  }, []);

  return (
    <div className={classes.root}>
      <div className={classes.inputButton}>
        <input
          className={classes.input}
          id="contained-button-file"
          style={{
            display: "none",
          }}
          type="file"
          onChange={onSelectImages}
        />
        <label htmlFor="contained-button-file">
          <Button
            variant="contained"
            color="secondary"
            size="large"
            className={classes.button}
            component="span"
          >
            Upload Model
          </Button>
        </label>
        {modelFile && (
          <Typography style={{ marginTop: 10 }}>{modelFile.name}</Typography>
        )}
      </div>
    </div>
  );
}
