import React, {useContext, useEffect} from "react";
import { makeStyles } from "@material-ui/core/styles";
import LinearProgress from "@material-ui/core/LinearProgress";
import Box from "@material-ui/core/Box";
import Button from "@material-ui/core/Button";
import { Typography } from "@material-ui/core";

import ResultTable from "./ResultTable";
import { AppContext } from "App";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
  boxStyle: {
    height: 500,
    borderStyle: "inset",
    boxShadow: "inset 0 0 4px #000000",
    width: "45%",
    margin: "48px auto",
    overflow: 'hidden scroll'
  },
}));

const textList = ["Hi", "Started the Process", "Working on Images"];

export default function ResultPage() {
  const classes = useStyles();
  const { appState, appMethods } = useContext(AppContext);
  const [loading, setLoading] = React.useState(true);
  const [log, setLog] = React.useState([])
  const [result, setResult] = React.useState(null)

  const setToggle = () => {
    setLoading(!loading);
  };
  
  let onMessageReceived = (msg) => {
    console.log("Msg recieved in results page:- ", msg);
    if(msg.type === 'log'){
      setLog(prevState => {
        return [...prevState, msg.message]
      })
    }else if(msg.type === 'result'){
      setResult(JSON.parse(msg.message))
      setLoading(!loading);
    }
    
  };

  useEffect(() => 
  {
    appMethods.updateSocketMsgHandler(onMessageReceived)
  }, [])

  return (
    <div className={classes.root}>
      {loading ? (
        <React.Fragment>
          <LinearProgress color="secondary" />
          <Box className={classes.boxStyle}>
            <div style={{ margin: 16 }}>
              {log.map((text) => (
                <>
                <Typography
                  variant="caption"
                  display="block"
                  gutterBottom
                  style={{ fontSize: "0.9rem", fontFamily: "monospace", whiteSpace: 'pre-wrap' }}
                >
                  {text}
                </Typography>
                </>
              ))}
            </div>
          </Box>
        </React.Fragment>
      ) : (
        <ResultTable result={result}/>
      )}
    </div>
  );
}
