import React, { memo, useEffect, useState, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import { Typography } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { Card, CardMedia, CardContent, FormLabel } from "@material-ui/core";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import InputLabel from "@material-ui/core/InputLabel";

import { API_URL, EMOTION_VALUES } from "consts";
import { AppContext } from "App";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  root: {
    // height: "100%",
    display: "flex",
    flexDirection: "column",
    margin: "0 10px",
    backgroundColor: "#fff",
    boxShadow: "inset 0 0 5px rgb(0 0 0 / 20%)",
  },
  grid: {
    display: "flex",
    justifyContent: "center",
    flex: "1 0 auto",
    overflowY: "auto",
    // maxHeight: 700,
    margin: 0,
    padding: "10px 0",
  },
  submit: {
    margin: "auto",
    marginTop: 24,
  },
  gridBorder: {
    display: "flex",
    justifyContent: "center",
    margin: "auto",
  },
  cardContainer: {
    width: 300,
    margin: 10,
    boxShadow: '0px 2px 1px -1px rgb(0 0 0 / 40%), 0px 1px 1px 0px rgb(0 0 0 / 40%), 0px 1px 3px 0px rgb(0 0 0 / 40%)'
  },
  img: {
    width: "100%",
  },
  media: {
    backgroundSize: '100% auto',
    paddingTop: "100%",
  },
  formControl: {
    width: "100%",
    margin: "10px 0",
    "&:last-child": {
      marginBottom: 0,
    },
  },
}));

function ImageSelection(props) {
  const classes = useStyles();
  const { files, handleNext } = props;
  const { appMethods, appState } = useContext(AppContext);
  const [label, setLabel] = React.useState({});
  const [gender, setGender] = React.useState({});

  React.useEffect(() => {
    console.log('assign gender and labels ')
    let g = {};
    let emotion = {};
    files.forEach((o) => {
      g[o.name] = "0";
      emotion[o.name] = "6";
    });
    setGender(g);
    setLabel(emotion);
  }, [files]);

  const onLabelChange = (e, fileName) => {
    setLabel((prevState) => ({ ...prevState, [fileName]: e.target.value }));
  };

  const onGenderChange = (e, fileName) => {
    setGender((prevState) => ({ ...prevState, [fileName]: e.target.value }));
  };

  const onSubmit = (g, l) => {
    var requests = []
    files.forEach((file) => {
      let newFile = new File(
        [file],
        file.name + "__" + l[file.name] + "__" + g[file.name] + "__img"
      );
      var formData = new FormData()
      formData.append('file', newFile)

      requests.push(axios.post(API_URL + '/files/'+appState.login.userDetails.name, formData))
    });
    axios.all(requests).then(axios.spread((...res) => {
      axios.get(API_URL + '/sendCmd/'+appState.login.userDetails.name)
    }))
    handleNext();
  };

  useEffect(() => {
    appMethods.updateStepperSubmitHandler(() => onSubmit(gender, label));
  }, [gender, label]);

  return (
    <div className={classes.root}>
      <Grid container spacing={3} className={classes.grid}>
        {/* <Grid container  alignItems="flex-end" key={'header'} style={{borderTop: '1px solid grey', borderBottom: '1px solid grey'}}>
            <Grid item xs={4} className={classes.gridBorder}>
            <Typography >Image</Typography>
          </Grid>
          <Grid item xs={4} className={classes.gridBorder}>
          <Typography >Label</Typography>
          </Grid>
          <Grid item xs={4} className={classes.gridBorder}>
          <Typography >Sensitivity</Typography>
          </Grid>
        </Grid> */}
        {files.map((file, index) => {
          return (
            <Card key={index} className={classes.cardContainer}>
              <CardMedia
                className={classes.media}
                image={URL.createObjectURL(file)}
                title="Paella dish"
              />
              <CardContent>
                <Typography variant="body1" gutterBottom>
                  {file.name}
                </Typography>
                <FormControl variant="outlined" className={classes.formControl}>
                  <InputLabel id="demo-simple-select-outlined-label">
                    Select Emotion
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-outlined-label"
                    key={index}
                    variant="outlined"
                    id={"demo-simple-select" + index}
                    value={label[file.name] || "6"}
                    onChange={(e) => onLabelChange(e, file.name)}
                    label="Select Role"
                    labelWidth={600}
                  >
                    {Object.keys(EMOTION_VALUES).map((o, i) => {
                      return (
                        <MenuItem key={i} value={o}>
                          {EMOTION_VALUES[o]}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>

                <FormControl
                  component="fieldset"
                  className={classes.formControl}
                >
                  <FormLabel component="legend">Select Gender</FormLabel>
                  <RadioGroup
                    row
                    aria-label="gender"
                    name="role"
                    value={gender[file.name] || "0"}
                    onChange={(e) => onGenderChange(e, file.name)}
                  >
                    <FormControlLabel
                      value={"0"}
                      control={<Radio />}
                      label="Female"
                    />
                    <FormControlLabel
                      value={"1"}
                      control={<Radio />}
                      label="Male"
                    />
                  </RadioGroup>
                </FormControl>
              </CardContent>
            </Card>
          );
        })}
      </Grid>
      {/* <Button variant="contained" className={classes.submit} onClick={onSubmit} color="primary">
          Submit
      </Button> */}
    </div>
  );
}

export default memo(ImageSelection);
