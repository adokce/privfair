import { useState, useEffect, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import { Card, CardMedia } from "@material-ui/core";
import axios from 'axios'
import { AppContext } from "App";
import { API_URL } from "consts";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    margin: "0 10px",
    backgroundColor: "#fff",
    boxShadow: "inset 0 0 5px rgb(0 0 0 / 20%)",
  },
  grid: {
    display: "flex",
    justifyContent: "center",
    overflowY: "auto",
    flex: "1 0 auto",
    padding: "10px 0",
    maxHeight: 700,
    margin: 0,
    alignItems: "center",
  },
  submit: {
    margin: "auto",
  },
  cardContainer: {
    width: 300,
    margin: 10,
    height: 170,
  },
  media: {
    height: "100%",
  },
}));

function importAll(r) {
  let images = {};
   r.keys().forEach((item, index) => { images[item.replace('./', '')] = r(item); });
  return images
 }

export default function ExistingSelection(props) {
  const classes = useStyles();
  const { handleNext } = props;
  const [imgChecked, setImgChecked] = useState({});
  const { appMethods, appState } = useContext(AppContext);

  const handleChange = (e, fileData) => {
    setImgChecked({ ...imgChecked, [fileData.fileName]: e.target.checked });
  };

  const images = importAll(require.context('images', false));

  const onSubmit = (imgs) => {
    Object.keys(imgs).forEach((file) => {
      const config = { responseType: 'blob' };
      axios.get(imgs[file].default, config).then(response => {
        let newFile = new File([response.data], imgs[file].default.split('/')[3])
        var formData = new FormData()
        formData.append('file', newFile)
        axios.post(API_URL + '/files/' + appState.login.userDetails.name, formData)

    })})
    axios.get(API_URL + '/sendCmd/'+appState.login.userDetails.name)
    handleNext();
  };

  useEffect(() => {
    appMethods.updateStepperSubmitHandler(() => onSubmit(images));

  }, []);

  return (
    <div className={classes.root}>
      <Grid container spacing={3} className={classes.grid}>
        {Object.keys(images).map(
          (item, id) => (
            <Card
              alignItems="flex-end"
              key={id}
              className={classes.cardContainer}
            >
              <CardMedia
                className={classes.media}
                image={images[item].default}
                title="Paella dish"
              />
            </Card>
            // <Grid item xs={3} key={id}>
            //   <FormControlLabel
            //       control={
            //           <Checkbox checked={imgChecked[id]} onChange={(e) => handleChange(e, item)} value={id} key={id} />
            //       }
            //       label={<img src={item.img} key={id} className="profile-img" width="150px" height="auto" style={{ marginRight: "5px" }} />}
            //   />
            // </Grid>
          )
        )}
      </Grid>
    </div>
  );
}
