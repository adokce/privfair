import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100%",
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
  },
  button: {
    height: "fit-content",
    alignSelf: "center",
    margin: "0 24px",
  },
  inputButton: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
  },
}));

export default function OptionsMenu(props) {
  const classes = useStyles();
  const { setIsExisting, handleNext, setFiles } = props;

  const [model, setModel] = React.useState("");

  const onSelectImages = (e) => {
    let uploadedFiles = Array.from(e.target.files);
    setFiles(uploadedFiles);
    setIsExisting(false);
    handleNext();
  };

  const onExistingImages = () => {
    setIsExisting(true);
    handleNext();
  };

  const handleModel = (e) => {};

  return (
    <div className={classes.root}>
      <div className={classes.inputButton}>
        <input
          accept="image/*"
          className={classes.input}
          id="contained-button-file"
          multiple
          style={{
            display: "none",
          }}
          type="file"
          onChange={onSelectImages}
        />
        <label htmlFor="contained-button-file">
          <Button
            variant="contained"
            color="secondary"
            size="large"
            className={classes.button}
            component="span"
          >
            Upload Images
          </Button>
        </label>
      </div>

      <Button
        variant="contained"
        color="secondary"
        size="large"
        className={classes.button}
        onClick={onExistingImages}
      >
        Upload from Sample Images
      </Button>
    </div>
  );
}
