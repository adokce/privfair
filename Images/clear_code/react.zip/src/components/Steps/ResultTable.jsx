import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const useStyles = makeStyles((theme) => ({
  table: {
    minWidth: 650,
  },
  headerStyle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
  },
}));

const testData = {
  "OA accuracy": 0.9372711181640625,
  "Male": {
    "TPR": {
      "0": 0.8889007568359375,
      "1": 1,
      "2": 0,
      "3": 0.9999847412109375,
      "4": 0,
      "5": 0,
      "6": 0
    },
    "FPR": {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0.0416717529296875,
      "5": 0,
      "6": 0
    },
    "Acc": 0.9583282470703125
  },
  "Female": {
    "TPR": {
      "0": 0.8750152587890625,
      "1": 0.8750152587890625,
      "2": 0,
      "3": 0.9999847412109375,
      "4": 0,
      "5": 0,
      "6": 0
    },
    "FPR": {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0.041656494140625,
      "5": 0,
      "6": 0
    },
    "Acc": 0.9166717529296875
  }
}

const headers = ['TPR', 'FPR', 'Acc']
const nheaders = ['0', '1', '2', '3', '4', '5', '6']

export default function ResultTable(props) {
  const classes = useStyles();

  const [overAcc, setOverAcc] = React.useState(null)
  const [data, setData] = React.useState(null)

  React.useEffect(() => {
    let a = {...props.result}
    setOverAcc(a["OA accuracy"])
    delete a["OA accuracy"]
    setData(a)
  }, [props.result])

  return data !== null && (
    <TableContainer component={Paper} style={{ margin: "auto" }}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell></TableCell>
            {headers.map((header) => (
              header === 'Acc' ? (
                <TableCell key={header} align="center" className={classes.headerStyle}>{header}</TableCell>
              ) : (
                <TableCell key={header} align="center" colSpan={7} className={classes.headerStyle}>{header}</TableCell>
              )
            ))}
          </TableRow>
          <TableRow>
            <TableCell></TableCell>
            {headers.map((header) => {
              return header !== 'Acc' ? (
                nheaders.map(nh => (
                  <TableCell key={nh+'nhead'} align="center" className={classes.headerStyle}>{nh}</TableCell>
                ))
              ) : (
                <TableCell key={header+'-nhead'} align="center" className={classes.headerStyle}></TableCell>
              )})}
          </TableRow>
        </TableHead>
        <TableBody>
          {Object.keys(data).map((row) => (
          <TableRow key={row}>
            <TableCell align="center">{row}</TableCell>
              {headers.map((header) => {
              return header !== 'Acc' ? (
                nheaders.map(nh => (
                  <TableCell key={nh + '-row'} align="center">{data[row][header][nh]}</TableCell>
                ))
              ) : (
                <TableCell key={header+ '-row'} align="center">{data[row][header]}</TableCell>
              )})}
            </TableRow>)
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
