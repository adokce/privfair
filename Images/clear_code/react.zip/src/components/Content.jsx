import React, { useContext, useState, useRef, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import Button from "@material-ui/core/Button";
import { Card } from "@material-ui/core";
import SockJsClient from "react-stomp";
import { v4 as uuidv4 } from "uuid";

import ExistingSelection from "./Steps/Evaluator/ExistingSelection";
import ImageSelection from "./Steps/Evaluator/ImageSelection";
import EOptionsMenu from "./Steps/Evaluator/OptionsMenu";
import ResultPage from "./Steps/ResultPage";
import MOOptionsMenu from "./Steps/ModelOwner/OptionsMenu";
import { AppContext } from "App";
import {API_URL} from '../consts'

const SOCKET_URL = API_URL+"/ws";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    height: "calc(100vh - 112px)",
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#f5f5f5",
  },
  stepper: {
    backgroundColor: "#f5f5f5",
  },
  content: {
    flexGrow: 1,
    overflowY: 'auto'
  },
  buttonGroup: {},
  footer: {
    display: "flex",
    padding: 10,
    justifyContent: "space-between",
  },
  button: {
    marginRight: theme.spacing(1),
  },
  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
}));

export default function Content() {
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);
  const [isExisting, setIsExisting] = React.useState(false);
  const [files, setFiles] = React.useState([]);
  const [modelFile, setModelFile] = useState(null);
  const { appState, appMethods } = useContext(AppContext);
  const steps =
    appState.login.role === "evaluator"
      ? [
          "Select Images",
          isExisting ? "Sample Set" : "Annotate Uploaded Images",
          "Results",
        ]
      : ["Select Model", "Results"];
  const clientRef = useRef();

  let onConnected = () => {
    if (!localStorage.getItem("sessionId")) {
      localStorage.setItem("sessionId", uuidv4());
    }
    // create session ID
    // create a id and store in local storage
  };

  let onMessageReceived = (msg) => {
    console.log("Msg recieved:- ", msg);
  };

  const getStepContent = (step) => {
    if (appState.login.role === "evaluator") {
      switch (step) {
        case 0:
          return (
            <EOptionsMenu
              setIsExisting={setIsExisting}
              handleNext={handleNext}
              setFiles={setFiles}
            />
          );
        case 1:
          return isExisting ? (
            <ExistingSelection handleNext={handleNext} />
          ) : (
            <ImageSelection files={files} handleNext={handleNext} />
          );
        case 2:
          return <ResultPage />;
        default:
          return "Unknown step";
      }
    } else {
      switch (step) {
        case 0:
          return (
            <MOOptionsMenu
              handleNext={handleNext}
              modelFile={modelFile}
              setModelFile={setModelFile}
            />
          );
        case 1:
          return <ResultPage />;
        default:
          return "Unknown step";
      }
    }
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  useEffect(() => {
    appMethods.updateStepperSubmitHandler(handleNext);
  }, []);

  useEffect(() => {
    if(activeStep === 0){
      appMethods.updateSocketMsgHandler(onMessageReceived)
      // setTimeout(() => clientRef.current.sendMessage('/app/news', "Hello"), 100)
    }
  }, [activeStep])

  return (
    <Card className={classes.root}>
      <Stepper activeStep={activeStep} className={classes.stepper}>
        {steps.map((label, index) => {
          return (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          );
        })}
      </Stepper>

      <div className={classes.content}>{getStepContent(activeStep)}</div>

      <div className={classes.footer}>
        <Button onClick={handleReset} className={classes.button}>
          Reset
        </Button>
        {(activeStep > 0 || (modelFile && activeStep >= 0)) &&
          activeStep < steps.length - 1 && (
            <Button
              variant="contained"
              className={classes.submit}
              onClick={appState.handlers.stepperSubmitHandler}
              color="primary"
            >
              Submit
            </Button>
          )}
      </div>

      <SockJsClient
        url={SOCKET_URL}
        ref={(client) => {
          clientRef.current = client;
        }}
        topics={["/topic/view/"+appState.login.userDetails.name, "/topic/news"]}
        onConnect={onConnected}
        onDisconnect={() => console.log("Disconnected!")}
        onMessage={appState.handlers.sockMsgHandler}
        debug={true}
      />
    </Card>
  );
}
