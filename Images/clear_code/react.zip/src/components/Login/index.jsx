import React, { useState, useCallback, memo, useContext } from "react";
import Button from "@material-ui/core/Button";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import FormControl from "@material-ui/core/FormControl";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  InputLabel,
  OutlinedInput,
  IconButton,
  FormHelperText,
  Container,
} from "@material-ui/core";
import { Visibility as VisibilityIcon } from "@material-ui/icons";
import { values, cloneDeep } from "lodash";
import { useHistory } from "react-router-dom";

import formJson from "./loginForm.json";
import { checkValidity, getIcon } from "utils";
import RegistrationModal from "./Register";
import { AppContext } from "App";
import axios from "axios";
import { API_URL } from "consts";

const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    alignItems: "center",
    height: "calc(100vh - 120px)",
  },
  root: {
    display: "flex",
    flexDirection: "column",
  },
  loginButton: {
    marginTop: 8,
  },
  margin: {
    marginTop: 10,
    marginBottom: 15,
  },
  textField: {
    width: "100%",
  },
  actionButtons: {
    display: "flex",
    justifyContent: "space-between",
  },
  modal: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    border: "2px solid #000",
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
  },
}));

function Login(props) {
  const classes = useStyles();

  const [role, setRole] = useState("evaluator");
  const [form, setForm] = useState(formJson);
  const [showPassword, setShowPassword] = useState(false);
  const [modalOpen, setModalOpen] = React.useState(false);
  const { appMethods } = useContext(AppContext);
  const history = useHistory();

  const handleChange = (event) => {
    setRole(event.target.value);
  };

  const onLogin = (e) => {
    e.preventDefault();
    let data = {}

    values(form).forEach(input => data[input.dbId] = input.inputProps.value)
    data = {...data, role: role}

    axios.post(API_URL + "/login", data).then(res => {
      appMethods.loginHandler(role, data.name);
      history.push("/content");
    })
    // appMethods.loginHandler(role);
    // history.push("/content");
  };

  const onRegister = () => {
    setModalOpen(true);
  };

  const onGuestLogin = () => {};

  const handleModalClose = () => {
    setModalOpen(false);
  };

  const inputChangeHandler = useCallback(
    (value, id) => {
      let updatedForm = cloneDeep(form);
      let updateInputField = null;
      updateInputField = updatedForm[id];

      updateInputField.inputProps.value = value.replace(/ /g, "");

      const [error, helperText] = checkValidity(
        updateInputField.inputProps,
        updateInputField.validations
      );
      updateInputField.inputProps.error = error;
      updateInputField.inputProps.helperText = helperText;

      updatedForm[id] = updateInputField;
      setForm(updatedForm);
    },
    [form]
  );

  const handleClickShowPassword = () => {
    setShowPassword((prevState) => !prevState);
  };

  return (
    <Container maxWidth={false} className={classes.container}>
      <Grid container justifyContent="center">
        <Grid item xs={4}>
          <form className={classes.root} onSubmit={onLogin}>
            <FormControl component="fieldset">
              <FormLabel component="legend">Select Role</FormLabel>
              <RadioGroup
                row
                aria-label="gender"
                name="role"
                value={role}
                onChange={handleChange}
              >
                <FormControlLabel
                  value="evaluator"
                  control={<Radio />}
                  label="Evaluator"
                />
                <FormControlLabel
                  value="owner"
                  control={<Radio />}
                  label="Model Owner"
                />
              </RadioGroup>
            </FormControl>
            {values(formJson).map((input) => (
              <FormControl
                key={input.id}
                className={classes.margin}
                variant="outlined"
              >
                <InputLabel htmlFor={input.id}>{input.title}</InputLabel>
                <OutlinedInput
                  id={input.id}
                  type={
                    showPassword && input.id === "password"
                      ? "text"
                      : input.inputProps.type
                  }
                  defaultValue={input.inputProps.value}
                  className={classes.textField}
                  error={input.inputProps.error}
                  onChange={(e) => inputChangeHandler(e.target.value, input.id)}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() =>
                          input.id === "password"
                            ? handleClickShowPassword()
                            : {}
                        }
                        edge="end"
                      >
                        {showPassword && input.id === "password" ? (
                          <VisibilityIcon />
                        ) : (
                          getIcon(input.iconType)
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
                {input.inputProps.error && (
                  <FormHelperText error id={input.id + "-error"}>
                    {input.inputProps.helperText}
                  </FormHelperText>
                )}
              </FormControl>
            ))}

            <div className={classes.actionButtons}>
              <Button
                variant="outlined"
                onClick={onRegister}
                className={classes.loginButton}
                color="primary"
              >
                Register
              </Button>
              <Button
                variant="contained"
                type="submit"
                className={classes.loginButton}
                color="primary"
              >
                Login
              </Button>
            </div>
          </form>
        </Grid>
      </Grid>

      <RegistrationModal open={modalOpen} handleClose={handleModalClose} />
    </Container>
  );
}

export default memo(Login);
