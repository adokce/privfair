import { useState, useCallback, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Visibility as VisibilityIcon } from "@material-ui/icons";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Button,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  FormHelperText,
  InputAdornment,
  IconButton,
} from "@material-ui/core";
import { values, cloneDeep } from "lodash";
import { useHistory } from "react-router-dom";

import { checkValidity, getIcon } from "utils";
import formJson from "./registrationForm.json";
import { AppContext } from "App";

const useStyles = makeStyles((theme) => ({
  formControl: {
    width: 300,
    marginTop: 10,
    marginBottom: 15,
  },
  formContainer: {
    display: "flex",
    flexDirection: "column",
  },
}));

const Registration = ({ open, handleClose }) => {
  const classes = useStyles();
  const [showPassword, setShowPassword] = useState({
    password: false,
    confirmPassword: false,
  });
  const [role, setRole] = useState("");
  const [form, setForm] = useState(formJson);
  const { appMethods } = useContext(AppContext);
  const history = useHistory();

  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  const inputChangeHandler = useCallback(
    (value, id) => {
      let updatedForm = cloneDeep(form);
      let updateInputField = null;
      updateInputField = updatedForm[id];

      updateInputField.inputProps.value = value.replace(/ /g, "");

      const [error, helperText] = checkValidity(
        updateInputField.inputProps,
        updateInputField.validations
      );
      updateInputField.inputProps.error = error;
      updateInputField.inputProps.helperText = helperText;

      updatedForm[id] = updateInputField;
      setForm(updatedForm);
    },
    [form]
  );

  const handleClickShowPassword = (id) => {
    setShowPassword((prevState) => ({ ...prevState, [id]: !prevState[id] }));
  };

  const onRegister = (e) => {
    e.preventDefault();
    appMethods.loginHandler("Evaluator");
    history.push("/content");
  };

  return (
    <Dialog
      aria-labelledby="form-dialog-title"
      open={open}
      onClose={handleClose}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <DialogTitle id="form-dialog-title">Registeration</DialogTitle>
      <form onSubmit={onRegister}>
        <DialogContent className={classes.formContainer}>
          <FormControl variant="outlined" className={classes.formControl}>
            <InputLabel id="demo-simple-select-outlined-label">
              Select Role
            </InputLabel>
            <Select
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              value={role}
              onChange={handleRoleChange}
              label="Select Role"
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value="Evaluator">Evaluator</MenuItem>
              <MenuItem value="Model Owner">Model Owner</MenuItem>
            </Select>
          </FormControl>
          {values(formJson).map((input) => (
            <FormControl
              key={input.id}
              className={classes.formControl}
              variant="outlined"
            >
              <InputLabel htmlFor={input.id}>{input.title}</InputLabel>
              <OutlinedInput
                id={input.id}
                type={
                  showPassword[input.id] &&
                  (input.id === "password" || input.id === "confirmPassword")
                    ? "text"
                    : input.inputProps.type
                }
                defaultValue={input.inputProps.value}
                className={classes.textField}
                error={input.inputProps.error}
                onChange={(e) => inputChangeHandler(e.target.value, input.id)}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() =>
                        input.id === "password" ||
                        input.id === "confirmPassword"
                          ? handleClickShowPassword(input.id)
                          : {}
                      }
                      edge="end"
                    >
                      {showPassword[input.id] &&
                      (input.id === "password" ||
                        input.id === "confirmPassword") ? (
                        <VisibilityIcon />
                      ) : (
                        getIcon(input.iconType)
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                labelWidth={input.id === "confirmPassword" ? 170 : 72}
              />
              {input.inputProps.error && (
                <FormHelperText error id={input.id + "-error"}>
                  {input.inputProps.helperText}
                </FormHelperText>
              )}
            </FormControl>
          ))}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} variant="contained">
            Cancel
          </Button>
          <Button type="submit" variant="contained" color="primary">
            Signup
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default Registration;
