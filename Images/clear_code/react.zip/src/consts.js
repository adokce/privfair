export const EMOTION_VALUES = {
  6: "neutral",
  3: "happy",
  4: "sad",
  0: "angry",
  2: "fearful",
  1: "disgust",
  5: "surprised",
};

export const GENDER_VALUES = { 0: "male", 1: "female" };

export const VALIDATION = {
  formFields: {
    empty: "This field cannot be blank",
  },
};

export const API_URL = "http://localhost:8080"
