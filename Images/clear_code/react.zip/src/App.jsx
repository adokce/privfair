import { useMemo, createContext, useReducer } from "react";
import { Switch, Route } from "react-router-dom";

import Login from "./components/Login";
import Content from "./components/Content";
import Layout from "./components/Layout";
import appReducer from "appReducer";

export const AppContext = createContext({
  appState: {},
  appMethods: {},
});

const App = () => {
  const initState = useMemo(
    () => ({
      login: {
        status: false,
        role: null,
        userDetails: {
          name: "Test-user",
        },
      },
      handlers: {
        stepperSubmitHandler: () => {},
        sockMsgHandler: () => {}
      },
      results: []
    }),
    []
  );

  const [appState, dispatch] = useReducer(appReducer, initState);
  const appMethods = useMemo(
    () => ({
      loginHandler: (role, name) => dispatch({ type: "LOGIN", role, name }),
      logoutHandler: () => dispatch({ type: "LOGOUT" }),
      updateStepperSubmitHandler: (cb) =>
        dispatch({ type: "UPDATE_STEPPER_SUBMIT_HANDLER", cb }),
      updateSocketMsgHandler: (cb) => dispatch({ type: 'UPDATE_SOCKET_MSG_HANDLER', cb}),
      resultProgress: (msg) => dispatch({type: 'RESULT_PROGRESS', msg})
    }),
    []
  );


  return (
    <AppContext.Provider value={{ appState, appMethods }}>
      <Layout {...{ logout: appMethods.logoutHandler }}>
        <Switch>
          <Route path="/login">
            <Login />
          </Route>
          {appState.login.status && (
            <Route path="/content">
              <Content />
            </Route>
          )}
          <Route path="/">
            <Login />
          </Route>
        </Switch>
      </Layout>
    </AppContext.Provider>
  );
};

export default App;
