import {
  AccountCircle as AccountCircleIcon,
  VisibilityOff as VisibilityOffIcon,
  Visibility as VisibilityIcon,
} from "@material-ui/icons";

import { VALIDATION } from "consts";

export const checkValidity = (inputProps, validations) => {
  let isValid = true;
  let errMsg = "";
  const value = inputProps.value;

  if (validations.required) {
    isValid = value !== "";
    errMsg = !isValid ? VALIDATION.formFields.empty : "";
  }

  if (value !== "") {
    //   if (validations.isEmail && isValid && value[0] !== '#') {
    //     const pattern = /^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@target.com$/
    //     isValid = pattern.test(value)
    //     errMsg = !isValid ? VALIDATION.formFields.email : ''
    //   }
  }

  return [!isValid, errMsg];
};

export function getIcon(type) {
  let icon = null;

  switch (type) {
    case "account":
      icon = <AccountCircleIcon />;
      break;
    case "password":
      icon = <VisibilityOffIcon />;
      break;
    default:
      break;
  }

  return icon;
}

export const updateObject = (oldObj, newObj) => ({
  ...oldObj,
  ...newObj,
});
